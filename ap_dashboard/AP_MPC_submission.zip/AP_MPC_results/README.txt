AP_MPC_full_project results
Peak glucose: 140.00 mg/dL
Settling time: 30.0 sec (0.5 min)
Time-in-range (70-140 mg/dL): 100.00%
